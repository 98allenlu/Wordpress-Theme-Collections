<?php
/**
 * Sidebar - The Hero Canvas Widget Area
 *
 * @package LAB Theme
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( is_active_sidebar( 'social' ) ) {

	dynamic_sidebar( 'social' );

}

<div class="image-module module <?= $module->custom_container_classes ?>">
	<div class="img-full">
		<img src="<?php echo $module->image['url']; ?>">
	</div>
</div>

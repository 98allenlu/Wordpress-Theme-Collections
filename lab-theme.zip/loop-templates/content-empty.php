<?php
/**
 * Content empty partial template
 *
 * @package LAB Theme
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

the_content();
